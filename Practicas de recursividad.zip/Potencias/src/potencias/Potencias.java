/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package potencias;

import javax.swing.JOptionPane;
import static javax.swing.JOptionPane.showMessageDialog;

/**
 *
 * @author Takitos13
 */
public class Potencias {
    public static void main(String[] args) {
        int a,b;
        a=Integer.parseInt(JOptionPane.showInputDialog("Dame un numero: "));
        b=Integer.parseInt(JOptionPane.showInputDialog("Dime la potencia: "));
        showMessageDialog(null,potencia(a,b));
    }
    
    public static boolean espar(int numero1){
         if(numero1==0)return true; return(esimpar(numero1-1));
      }
     public static boolean esimpar(int numero2){
         if(numero2==0)return false; return(espar(numero2-1));
      }
     public static int suma(int a, int b){
      if(b==0) return a;
      else if(a==0) return b; else return 1+suma(a,b-1);
     }
    
     public static int potencia(int a, int b){
      if(b==0) return 1;
     else return a*potencia(a,b-1);
     }
}
