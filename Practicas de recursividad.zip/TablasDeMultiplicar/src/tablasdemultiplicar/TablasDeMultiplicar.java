/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tablasdemultiplicar;

import javax.swing.JOptionPane;
import static javax.swing.JOptionPane.showMessageDialog;

/**
 *
 * @author Takitos13
 */
public class TablasDeMultiplicar {
    public static void main(String[] args) {
        int a;
        a=Integer.parseInt(JOptionPane.showInputDialog("Que tabla quieres?: "));
        showMessageDialog(null,"Tabla de multiplicar: \n"+tablaMultiplicar(a,10));
    }
    public static String tablaMultiplicar(int a, int b){
      if(b==1){ 
        return a+" x "+1+" = 1"+"\n";
      }else{
            int temp;
            temp=b;
            return tablaMultiplicar(a, b-1)+a+" x "+temp+" = "+(a*temp)+"\n";
           } 
    }
}
